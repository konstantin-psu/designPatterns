import pattpack.accountP.*;

/**
 *  Economy implementation of a factory of accounts.
 *  @see <A HREF="../../doc/pattpack/accountP/index.html">package account</A>.
 */
public class PrototypeEconomy extends PrototypeIF {
    /** The prototype account for cloning. */
    private static final AccountEconomy protoAccount
	= new AccountEconomy (-1);
    /** The prototype security manager for cloning. */
    private static final SecurityManagerEconomy protoSecurityManager
	= new SecurityManagerEconomy ();
    /**
     *  Create an economy account.
     *  @param loginId the numeric id of the created account.
     *  @return a new economy account.
     */
    public AccountIF createAccount (int loginId) {
	AccountIF account = (AccountIF) protoAccount.clone ();
	account.setLoginId (loginId);
	return account;
    }
    /**
     *  Create an economy security manager.
     *  @return a new economy security manager.
     */
    public SecurityManagerIF createSecurityManager () {
	return (SecurityManagerIF) protoSecurityManager.clone ();
    }
}
